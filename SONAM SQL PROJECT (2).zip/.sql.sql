   --      OBJECTIVE QUESTIONS

-- Q.1. Are there any tables with duplicate or missing null values? If so, how would you handle them?
 -- Find duplicate values
SELECT username, COUNT(*)
FROM users
GROUP BY username
HAVING COUNT(*) > 1;

-- Find NULL values
SELECT * FROM users
WHERE username IS NULL;

-- Q.2. What is the distribution of user activity levels (e.g., number of posts, likes, comments) across the user base?
SELECT Activity_Level,
    COUNT(*) AS Number_of_Users
FROM (
    SELECT u.id,
        (COUNT(DISTINCT p.id) + COUNT(DISTINCT l.photo_id) + COUNT(DISTINCT c.id)) AS total_actions,
        CASE 
            WHEN (COUNT(DISTINCT p.id) + COUNT(DISTINCT l.photo_id) + COUNT(DISTINCT c.id)) > 50 THEN 'Power User'
            WHEN (COUNT(DISTINCT p.id) + COUNT(DISTINCT l.photo_id) + COUNT(DISTINCT c.id)) BETWEEN 10 AND 50 THEN 'Active User'
            WHEN (COUNT(DISTINCT p.id) + COUNT(DISTINCT l.photo_id) + COUNT(DISTINCT c.id)) BETWEEN 1 AND 9 THEN 'Occasional User'
            ELSE 'Inactive/Lurker'
        END AS Activity_Level
    FROM users u
    LEFT JOIN photos p ON u.id = p.user_id
    LEFT JOIN likes l ON u.id = l.user_id
    LEFT JOIN comments c ON u.id = c.user_id
    GROUP BY u.id
) AS user_stats
GROUP BY Activity_Level
ORDER BY Number_of_Users DESC;

-- Q.3. Calculate the average number of tags per post (photo_tags and photos tables).
SELECT AVG(tag_count) AS avg_tags_per_post
FROM (
    SELECT photo_id,COUNT(tag_id) AS tag_count
    FROM photo_tags
    GROUP BY photo_id
) AS sub;



-- Q.4.Identify the top users with the highest engagement rates (likes, comments) on their posts and rank them. 
SELECT username,total_engagement / total_posts AS engagement_rate,
    RANK() OVER (ORDER BY (total_engagement / total_posts) DESC) AS engagement_rank
FROM (
    SELECT u.username,
        COUNT(DISTINCT p.id) AS total_posts,
        (COUNT(DISTINCT l.user_id, l.photo_id) + COUNT(DISTINCT c.id)) AS total_engagement
    FROM users u
    JOIN photos p ON u.id = p.user_id
    LEFT JOIN likes l ON p.id = l.photo_id
    LEFT JOIN comments c ON p.id = c.photo_id
    GROUP BY u.id
) AS stats
WHERE total_posts > 0
LIMIT 10;


-- Q.5.Which users have the highest number of followers and followings?
SELECT u.id,u.username,
    COUNT(DISTINCT f1.follower_id) AS followers_count,
    COUNT(DISTINCT f2.followee_id) AS following_count
FROM users u
LEFT JOIN follows f1 ON u.id = f1.followee_id
LEFT JOIN follows f2 ON u.id = f2.follower_id
GROUP BY u.id, u.username
ORDER BY followers_count DESC, following_count DESC;


-- Q.6.Calculate the average engagement rate (likes, comments) per post for each user.
SELECT u.id,u.username,
    AVG(COALESCE(l.like_count, 0) + COALESCE(c.comment_count, 0)) AS avg_engagement_per_post
FROM users u
JOIN photos p ON u.id = p.user_id
LEFT JOIN (
    SELECT photo_id, COUNT(*) AS like_count
    FROM likes
    GROUP BY photo_id
) l ON p.id = l.photo_id
LEFT JOIN (
    SELECT photo_id, COUNT(*) AS comment_count
    FROM comments
    GROUP BY photo_id
) c ON p.id = c.photo_id
GROUP BY u.id, u.username;


-- Q.7.Get the list of users who have never liked any post (users and likes tables)
SELECT u.id,u.username
FROM users u
LEFT JOIN likes l ON u.id = l.user_id
WHERE l.user_id IS NULL;


-- Q.8.How can you leverage user-generated content (posts, hashtags, photo tags) to create more personalized and engaging ad campaigns?

SELECT u.id AS user_id,u.username,t.tag_name,
    COUNT(pt.photo_id) AS hashtag_usage,
    COUNT(DISTINCT p.id) AS total_posts
FROM users u
JOIN photos p ON u.id = p.user_id
JOIN photo_tags pt ON p.id = pt.photo_id
JOIN tags t ON pt.tag_id = t.id
GROUP BY u.id, u.username,t.tag_name
ORDER BY hashtag_usage DESC;

-- Q.9. Are there any correlations between user activity levels and specific content types (e.g., photos, videos, reels)? How can this information guide content creation and curation strategies?
SELECT u.id, u.username,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT l.photo_id) AS total_likes,
    COUNT(DISTINCT c.id) AS total_comments
FROM users u
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY u.id, u.username;



-- Q.10. Calculate the total number of likes, comments, and photo tags for each user.
SELECT u.id,u.username,
    COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes,
    COUNT(DISTINCT c.id) AS total_comments,
    COUNT(DISTINCT pt.photo_id, pt.tag_id) AS total_tags
FROM users u
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
LEFT JOIN photo_tags pt ON p.id = pt.photo_id
GROUP BY u.id, u.username;


-- Q.11 Rank users based on their total engagement (likes, comments, shares) over a month.
 SELECT u.id,u.username,
    COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes,
    COUNT(DISTINCT c.id) AS total_comments,
    (COUNT(DISTINCT l.user_id, l.photo_id) + COUNT(DISTINCT c.id)) AS total_engagement,
    RANK() OVER (ORDER BY 
        (COUNT(DISTINCT l.user_id, l.photo_id) + COUNT(DISTINCT c.id)) DESC
    ) AS rank_position
FROM users u
JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
WHERE MONTH(p.created_dat) = MONTH(CURRENT_DATE())
  AND YEAR(p.created_dat) = YEAR(CURRENT_DATE())
GROUP BY u.id, u.username;


-- Q.12.Retrieve the hashtags that have been used in posts with the highest average number of likes. Use a CTE to calculate the average likes for each hashtag first.
WITH tag_likes AS (
    SELECT t.id,t.tag_name,pt.photo_id,
        COUNT(l.user_id) AS like_count
    FROM tags t
    JOIN photo_tags pt ON t.id = pt.tag_id
    JOIN photos p ON pt.photo_id = p.id
    LEFT JOIN likes l ON p.id = l.photo_id
    GROUP BY t.id, t.tag_name, pt.photo_id
),
avg_likes_per_tag AS (
    SELECT tag_name,AVG(like_count) AS avg_likes
    FROM tag_likes
    GROUP BY tag_name
)
SELECT *
FROM avg_likes_per_tag
ORDER BY avg_likes DESC;


-- Q.13.Retrieve the users who have started following someone after being followed by that person
SELECT 
    f1.follower_id AS user_id, f1.followee_id AS followed_user
FROM
    follows f1
        JOIN
    follows f2 ON f1.follower_id = f2.followee_id
        AND f1.followee_id = f2.follower_id
WHERE
    f1.created_at > f2.created_at;




--          SUBJECTIVE QUESTIONS


-- Q.1.Based on user engagement and activity levels, which users would you consider the most loyal or valuable? How would you reward or incentivize these users?
SELECT u.id,u.username,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes,
    COUNT(DISTINCT c.id) AS total_comments,
    (COUNT(DISTINCT l.user_id, l.photo_id) + COUNT(DISTINCT c.id)) AS total_engagement
FROM users u
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY u.id, u.username
ORDER BY total_engagement DESC;


-- Q.2.For inactive users, what strategies would you recommend to re-engage them and encourage them to start posting or engaging again?
SELECT u.id,u.username,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT l.photo_id, l.user_id) AS total_likes,
    COUNT(DISTINCT c.id) AS total_comments
FROM users u
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON u.id = l.user_id
LEFT JOIN comments c ON u.id = c.user_id
GROUP BY u.id, u.username
HAVING total_posts = 0 
   AND total_likes = 0 
   AND total_comments = 0;
   
   
   -- Q.3.Which hashtags or content topics have the highest engagement rates? How can this information guide content strategy and ad campaigns?
SELECT t.tag_name AS "Hashtag", 
    COUNT(l.user_id) AS "Total_Likes",
    COUNT(DISTINCT p.id) AS "Total_Photos",
    (COUNT(l.user_id) / COUNT(DISTINCT p.id)) AS "Engagement_Ratio"
FROM tags t
JOIN photo_tags pt ON t.id = pt.tag_id
JOIN photos p ON pt.photo_id = p.id
LEFT JOIN likes l ON p.id = l.photo_id
GROUP BY t.id
ORDER BY Total_Likes DESC
LIMIT 10;


-- Q.4.Are there any patterns or trends in user engagement based on demographics (age, location, gender) or posting times? How can these insights inform targeted marketing campaigns?
SELECT 
    HOUR(p.created_dat) AS posting_hour,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes,
    COUNT(DISTINCT c.id) AS total_comments,
    (COUNT(DISTINCT l.user_id, l.photo_id) + COUNT(DISTINCT c.id)) AS total_engagement
FROM photos p
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY posting_hour
ORDER BY total_engagement DESC;


-- Q.5.Based on follower counts and engagement rates, which users would be ideal candidates for influencer marketing campaigns? How would you approach and collaborate with these influencers?
SELECT u.id, u.username, 
    COUNT(DISTINCT f.follower_id) AS total_followers,
    COUNT(DISTINCT l.user_id) AS total_likes_received,
    (COUNT(DISTINCT l.user_id) / COUNT(DISTINCT p.id)) AS avg_engagement_per_post
FROM users u
LEFT JOIN follows f ON u.id = f.followee_id
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
GROUP BY u.id
HAVING total_followers > 0
ORDER BY total_likes_received DESC
LIMIT 10;


-- Q.6.Based on user behavior and engagement data, how would you segment the user base for targeted marketing campaigns or personalized recommendations?
SELECT u.id,u.username,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT l.photo_id, l.user_id) AS total_likes,
    COUNT(DISTINCT c.id) AS total_comments,
    (COUNT(DISTINCT l.photo_id, l.user_id) + COUNT(DISTINCT c.id)) AS total_engagement,
    CASE 
        WHEN COUNT(DISTINCT p.id) >= 10 
             AND (COUNT(DISTINCT l.photo_id, l.user_id) + COUNT(DISTINCT c.id)) >= 50 
            THEN 'Highly Active Users'
        WHEN COUNT(DISTINCT p.id) BETWEEN 5 AND 9 
            THEN 'Moderately Active Users'
        WHEN COUNT(DISTINCT p.id) > 0 
            THEN 'Low Active Users'
        ELSE 'Inactive Users'
    END AS user_segment
FROM users u
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON u.id = l.user_id
LEFT JOIN comments c ON u.id = c.user_id
GROUP BY u.id, u.username;


-- Q.7. If data on ad campaigns (impressions, clicks, conversions) is available, how would you measure their effectiveness and optimize future campaigns?
SELECT 
    DATE(u.created_at) AS "Join_Date",
    COUNT(DISTINCT u.id) AS "Total_Signups",
    COUNT(DISTINCT p.user_id) AS "Converted_Users",
    (COUNT(DISTINCT p.user_id) / COUNT(DISTINCT u.id) * 100) AS "Conversion_Rate_Pct"
FROM users u
LEFT JOIN photos p ON u.id = p.user_id 
    AND DATE(p.created_dat) = DATE(u.created_at)
GROUP BY Join_Date
ORDER BY Join_Date DESC;


-- Q.8.How can you use user activity data to identify potential brand ambassadors or advocates who could help promote Instagram's initiatives or events?
SELECT u.id,u.username,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT f.follower_id) AS followers_count,
    COUNT(DISTINCT l.user_id, l.photo_id) AS total_likes,
    COUNT(DISTINCT c.id) AS total_comments,
    (COUNT(DISTINCT l.user_id, l.photo_id) + COUNT(DISTINCT c.id)) AS total_engagement
FROM users u
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN follows f ON u.id = f.followee_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY u.id, u.username
ORDER BY total_engagement DESC, followers_count DESC;


-- Q.9. How would you approach this problem, if the objective and subjective questions weren't given?
-- No query need


-- Q.10. Assuming there's a "User_Interactions" table tracking user engagements, how can you update the "Engagement_Type" column to change all instances of "Like" to "Heart" to align with Instagram's terminology?
-- {Update user interactions
-- Set Engagement Type = ‘Heart’
-- Where Engagement Type = ‘Like’ ;}
